const express = require('express');
const bodyParser = require('body-parser');
const cronJobs = require('./cronJobs');
const taskRoutes = require('./routes/tasks');
const cors = require('cors'); // Import the CORS module

const app = express();
const PORT = process.env.PORT || 3000;

// Enable CORS middleware
app.use(cors());

// Body parser middleware
app.use(bodyParser.json());

// Define routes
app.use('/api', taskRoutes);

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
