const { DataTypes } = require('sequelize');
const sequelize = require('../config/database'); // Assuming you have a Sequelize instance named 'sequelize'

const Task = sequelize.define('Task', {
  title: {
    type: DataTypes.STRING,
    allowNull: false
  },
  description: {
    type: DataTypes.STRING,
    allowNull: false
  },
  due_date: {
    type: DataTypes.DATE,
    allowNull: false
  },
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  priority: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  status: {
    type: DataTypes.ENUM('TODO', 'IN_PROGRESS', 'DONE'),
    allowNull: false
  },
  deleted_at: {
    type: DataTypes.DATE,
    defaultValue: null
  }
});

module.exports = Task;
