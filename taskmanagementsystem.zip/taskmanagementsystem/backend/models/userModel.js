const { DataTypes } = require('sequelize');
const sequelize = require('../config/database'); // Assuming you have a Sequelize instance named 'sequelize'

const User = sequelize.define('User', {
  phone_number: {
    type: DataTypes.STRING,
    allowNull: false
  },
  priority: {
    type: DataTypes.ENUM('0', '1', '2'),
    allowNull: false
  },
  deleted_at: {
    type: DataTypes.DATE,
    defaultValue: null
  }
});

module.exports = User;
