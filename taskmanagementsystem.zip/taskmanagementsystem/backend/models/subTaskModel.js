const { DataTypes } = require('sequelize');
const sequelize = require('../config/database'); // Assuming you have a Sequelize instance named 'sequelize'

const SubTask = sequelize.define('SubTask', {
  task_id: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  status: {
    type: DataTypes.ENUM('0', '1'),
    allowNull: false
  },
  created_at: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW
  },
  updated_at: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW
  },
  deleted_at: {
    type: DataTypes.DATE,
    defaultValue: null
  }
});

module.exports = SubTask;
