const express = require('express');
const router = express.Router();
const taskController = require('../controllers/taskController');
const authMiddleware = require('../middlewares/authMiddleware');

// Routes for task-related APIs
router.post('/task', authMiddleware, taskController.createTask);
router.post('/subtask', authMiddleware, taskController.createSubTask);
router.get('/tasks', authMiddleware, taskController.getAllUserTasks);
router.get('/subtasks', authMiddleware, taskController.getAllUserSubTasks);
router.put('/task/:id', authMiddleware, taskController.updateTask);
router.put('/subtask/:id', authMiddleware, taskController.updateSubTask);
router.delete('/task/:id', authMiddleware, taskController.deleteTask);
router.delete('/subtask/:id', authMiddleware, taskController.deleteSubTask);

module.exports = router;
