const Task = require('../models/taskModel');
const SubTask = require('../models/subTaskModel');
const User = require('../models/userModel');
const { calculateTaskPriority } = require('../cronJobs');

// Controller functions for task-related APIs

exports.createTask = async (req, res) => {
  try {
    const { title, description, due_date } = req.body;
    const userId = req.user.id;

    // Create task in database
    const task = await Task.create({
      title,
      description,
      due_date,
      user_id: userId,
      priority: calculateTaskPriority(due_date),
      status: 'TODO'
    });

    res.status(201).json(task);
  } catch (error) {
    console.error('Error creating task:', error);
    res.status(500).json({ error: 'Failed to create task' });
  }
};

exports.createSubTask = async (req, res) => {
  try {
    const { task_id } = req.body;

    // Create sub task in database
    const subTask = await SubTask.create({
      task_id,
      status: 0
    });

    res.status(201).json(subTask);
  } catch (error) {
    console.error('Error creating subtask:', error);
    res.status(500).json({ error: 'Failed to create subtask' });
  }
};

exports.getAllUserTasks = async (req, res) => {
  try {
    const { priority, due_date } = req.query;
    const userId = req.user.id;

    // Fetch tasks from database based on filters
    const tasks = await Task.findAll({
      where: {
        user_id: userId,
        ...(priority && { priority }),
        ...(due_date && { due_date })
      },
      order: [['due_date', 'ASC']]
    });

    res.status(200).json(tasks);
  } catch (error) {
    console.error('Error fetching tasks:', error);
    res.status(500).json({ error: 'Failed to fetch tasks' });
  }
};

exports.getAllUserSubTasks = async (req, res) => {
  try {
    const { task_id } = req.query;

    // Fetch sub tasks from database based on task_id
    const subTasks = await SubTask.findAll({
      where: {
        task_id
      }
    });

    res.status(200).json(subTasks);
  } catch (error) {
    console.error('Error fetching subtasks:', error);
    res.status(500).json({ error: 'Failed to fetch subtasks' });
  }
};

exports.updateTask = async (req, res) => {
  try {
    const taskId = req.params.id;
    const { due_date, status } = req.body;

    // Update task in database
    await Task.update(
      { due_date, status },
      { where: { id: taskId } }
    );

    res.status(200).json({ message: 'Task updated successfully' });
  } catch (error) {
    console.error('Error updating task:', error);
    res.status(500).json({ error: 'Failed to update task' });
  }
};

exports.updateSubTask = async (req, res) => {
  try {
    const subTaskId = req.params.id;
    const { status } = req.body;

    // Update sub task in database
    await SubTask.update(
      { status },
      { where: { id: subTaskId } }
    );

    res.status(200).json({ message: 'Subtask updated successfully' });
  } catch (error) {
    console.error('Error updating subtask:', error);
    res.status(500).json({ error: 'Failed to update subtask' });
  }
};

exports.deleteTask = async (req, res) => {
  try {
    const taskId = req.params.id;

    // Soft delete task in database
    await Task.update(
      { deleted_at: new Date() },
      { where: { id: taskId } }
    );

    // Soft delete related sub tasks
    await SubTask.update(
      { deleted_at: new Date() },
      { where: { task_id: taskId } }
    );

    res.status(200).json({ message: 'Task deleted successfully' });
  } catch (error) {
    console.error('Error deleting task:', error);
    res.status(500).json({ error: 'Failed to delete task' });
  }
};

exports.deleteSubTask = async (req, res) => {
  try {
    const subTaskId = req.params.id;

    // Soft delete sub task in database
    await SubTask.update(
      { deleted_at: new Date() },
      { where: { id: subTaskId } }
    );

    res.status(200).json({ message: 'Subtask deleted successfully' });
  } catch (error) {
    console.error('Error deleting subtask:', error);
    res.status(500).json({ error: 'Failed to delete subtask' });
  }
};
