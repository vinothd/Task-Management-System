const fs = require('fs');
const crypto = require('crypto');

// Generate random JWT secret
const jwtSecret = crypto.randomBytes(32).toString('hex');

// Write JWT secret to config file
const configContent = `module.exports = {\n  JWT_SECRET: '${jwtSecret}'\n};`;
fs.writeFileSync('./config/config.js', configContent);

console.log('JWT secret generated and saved to config file.');
