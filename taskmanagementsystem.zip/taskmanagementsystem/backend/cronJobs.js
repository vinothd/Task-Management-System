const cron = require('node-cron');
const Task = require('./models/taskModel');
const User = require('./models/userModel');
const twilio = require('twilio');
const { TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER } = require('./config/config');

// Initialize Twilio client
const client = twilio(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);

// Function to calculate task priority based on due date
const calculateTaskPriority = (dueDate) => {
  const currentDate = new Date();
  const diffTime = dueDate - currentDate;
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays === 0) {
    return 0;
  } else if (diffDays <= 2) {
    return 1;
  } else if (diffDays <= 4) {
    return 2;
  } else {
    return 3;
  }
};

// Cron Logic for Changing Task Priority
cron.schedule('0 0 * * *', async () => {
  try {
    const tasks = await Task.findAll();

    tasks.forEach(async task => {
      const newPriority = calculateTaskPriority(task.due_date);
      if (task.priority !== newPriority) {
        await task.update({ priority: newPriority });
      }
    });
  } catch (error) {
    console.error('Error in changing task priority:', error);
  }
});

// Cron Logic for Voice Calling using Twilio
cron.schedule('0 9 * * *', async () => { // For example, call scheduled daily at 9 AM
  try {
    const users = await User.findAll({ order: [['priority', 'ASC']] });

    for (const user of users) {
      // Implement logic to check if user attended previous call
      // If not, make a call to this user using Twilio
      const call = await client.calls.create({
        twiml: '<Response><Say>Your task is overdue. Please check your tasks.</Say></Response>',
        to: user.phone_number,
        from: TWILIO_PHONE_NUMBER
      });

      console.log('Call SID:', call.sid);
    }
  } catch (error) {
    console.error('Error in voice calling cron job:', error);
  }
});

module.exports = {
  calculateTaskPriority
};
