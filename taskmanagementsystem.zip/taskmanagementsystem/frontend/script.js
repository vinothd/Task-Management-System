document.addEventListener('DOMContentLoaded', () => {
    const BASE_URL = 'http://localhost:3000'; // Replace with your backend base URL
    
    // Function to fetch all tasks
    async function fetchTasks() {
      try {
        const response = await fetch(`${BASE_URL}/tasks`);
        const data = await response.json();
        console.log('Tasks:', data);
        // Display tasks in the frontend
      } catch (error) {
        console.error('Error fetching tasks:', error);
      }
    }
  
    // Function to fetch all subtasks for a specific task ID
    async function fetchSubtasks(taskId) {
      try {
        const response = await fetch(`${BASE_URL}/tasks/${taskId}/subtasks`);
        const data = await response.json();
        console.log(`Subtasks for Task ${taskId}:`, data);
        // Display subtasks in the frontend
      } catch (error) {
        console.error(`Error fetching subtasks for Task ${taskId}:`, error);
      }
    }
  
    // Function to create a new task
    async function createTask(title, description, dueDate) {
      try {
        const response = await fetch(`${BASE_URL}/tasks`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            title,
            description,
            due_date: dueDate
          })
        });
        const data = await response.json();
        console.log('New task created:', data);
        // Handle success or display error message
      } catch (error) {
        console.error('Error creating task:', error);
      }
    }
  
    // Function to update task status
    async function updateTaskStatus(taskId, status) {
      try {
        const response = await fetch(`${BASE_URL}/tasks/${taskId}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            status
          })
        });
        const data = await response.json();
        console.log('Task status updated:', data);
        // Handle success or display error message
      } catch (error) {
        console.error('Error updating task status:', error);
      }
    }
  
    // Example usage
    fetchTasks(); // Fetch all tasks when the DOM content is loaded
  
    // Example: Fetch subtasks for Task with ID 1
    fetchSubtasks(1);
  
    // Example: Create a new task
    createTask('New Task', 'Description of new task', '2024-03-31');
  
    // Example: Update task status
    updateTaskStatus(1, 'DONE');
  });
  